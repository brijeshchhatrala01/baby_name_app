<?php

    include('connection.php');
    
    $baby_name = $_POST['baby_name'];
    
    $sql = "delete from baby_name where baby_name = '$baby_name'";
    
    mysqli_query($con,$sql);
    
?>
<?php

    include('connection.php');
    
    $filterword = $_REQUEST['filterword'];
    
    $sql ="select * from baby_name where gender = '$filterword'";
    
    $r = mysqli_query($con,$sql);
    $response = array();
    
    while($value = mysqli_fetch_array($r))
    {
        $row["id"] = $value["id"];
        $row["baby_name"] = $value["baby_name"];
        $row["meaning"] = $value["meaning"];
        $row["gender"] = $value["gender"];
        $row["religion"] = $value["religion"];
        $row["rashi"] = $value["rashi"];
        $row["is_favorite"] = $value["is_favorite"];
        
    
        array_push($response,$row);
        
        
    }
    echo json_encode($response);
    mysqli_close($con);
    

?>
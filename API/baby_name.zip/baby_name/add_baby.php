<?php
    include ('connection.php');
    
    $name = $_POST['baby_name'];
    $meaning = $_POST['meaning'];
    $gender = $_POST['gender'];
    $rashi = $_POST['rashi'];
    $religion = $_POST['religion'];
    $isFavorite = $_POST['is_favorite'];
    
    
    $insert = "insert into baby_name(baby_name,meaning,gender,religion,rashi,is_favorite) values ('$name','$meaning','$gender','$religion','$rashi','$isFavorite');";
    
    mysqli_query($con,$insert);
    
    mysqli_close($con);

?>
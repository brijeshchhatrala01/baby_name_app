<?php

    include('connection.php');
    
    $is_favorite = $_POST['is_favorite'];
    $baby_name = $_POST['baby_name'];
    
    $sql = "update baby_name set is_favorite = '$is_favorite' where baby_name = '$baby_name'";
    
    mysqli_query($con,$sql);
    
?>